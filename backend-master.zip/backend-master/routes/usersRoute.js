const express = require("express");
const Order = require("../models/Order.js");
const User = require("../models/User.js");
const userChecker = require("../middleware/userChecker.js");
const adminChecker = require("../middleware/adminChecker.js");

const router = express.Router();

router.get("/find/:id", async (req, res) => {
  try {
    const user = await User.findOne(
      { userID: req.params.id },
      { password: 0, resetPasswordCode: 0, resetPasswordExpires: 0 }
    );
    res.send(user.toObject());
  } catch (error) {
    console.error(error);
    res.status(500).send("Error getting user");
  }
});

router.get("/all", async (req, res) => {
  try {
    const users = await User.find({});
    res.send(users.map((user) => user.toObject()));
  } catch (error) {
    console.error(error);
    res.status(500).send("Error getting user");
  }
});

router.get("/total", async (req, res) => {
  try {
    const count = await User.countDocuments({});
    console.log({ count });
    res.send({ count });
  } catch (error) {
    console.error(error);
    res.status(500).send("Error getting users");
  }
});

router.get("/order", userChecker, async (req, res) => {
  try {
    const orders = await Order.find({ userID: req.user.userID });

    if (!orders) return res.status(404).send({ error: "Orders not found." });

    return res.send(orders);
  } catch (error) {
    res.status(500).send({ error: "Error finding order." });
  }
});

router.get("/delivery/all", adminChecker, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    const deliveryCount = await User.countDocuments({ role: "delivery" });
    const deliveries = await User.find(
      { role: "delivery" },
      { password: 0, resetPasswordCode: 0, resetPasswordExpires: 0 }
    )
      .sort({ firstname: 1 })
      .skip(startIndex)
      .limit(limit);

    const results = {
      page: page,
      limit: limit,
      totalPages: Math.ceil(deliveryCount / limit),
      totalDeliveries: deliveryCount,
      deliveries: deliveries,
    };

    res.send(results);
  } catch (error) {
    console.log(error);
    res.status(500).send({ error: "Error getting delivery clients" });
  }
});

module.exports = router;

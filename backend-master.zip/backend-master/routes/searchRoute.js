const express = require("express");
const Product = require("../models/Product.js");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const regex = new RegExp(req.query.q, "i");

    const products = await Product.find({
      $or: [
        { category: { $regex: regex } },
        { name: { $regex: regex } },
        { description: { $regex: regex } },
        { brand: { $regex: regex } },
      ],
    });

    if (!products) {
      return res
        .status(404)
        .send({ error: `Could not find anything related with ${req.query.q}` });
    }

    res.send(products);
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: `Could not search ${req.query.q}.` });
  }
});

module.exports = router;

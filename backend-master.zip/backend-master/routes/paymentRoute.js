const express = require("express");
const User = require("../models/User.js");
const Order = require("../models/Order.js");
const userChecker = require("../middleware/userChecker.js");
const { Chapa } = require("chapa-nodejs");

require("dotenv").config();

const chapa = new Chapa({
  secretKey: process.env.chapa_secret_key,
});

const router = express.Router();

router.post("/", userChecker, async (req, res) => {
  try {
    const user = await User.findOne({ userID: req.user.userID });
    const { firstname, lastname, email } = user;

    const tx_ref = await chapa.generateTransactionReference();

    const response = await chapa.initialize({
      first_name: firstname,
      last_name: lastname,
      email: email,
      currency: "ETB",
      amount: "1",
      tx_ref: tx_ref,
      callback_url: "https://ecom-8v3t.onrender.com/",
      return_url: "https://ecom-8v3t.onrender.com/",
      customization: {
        title: "Delivery Order",
        description: "Delivery Order Description",
      },
    });

    console.log(response);
    const verification = await chapa.verify(tx_ref);

    res.send({ response: response, verification: verification });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: `Could not perform transaction` });
  }
});

router.get("/complete", (req, res) => {
  res.send("Payment complete!");
});

module.exports = router;

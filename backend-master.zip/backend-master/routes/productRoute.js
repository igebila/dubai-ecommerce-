const express = require("express");
const Product = require("../models/Product");
const adminAuth = require("../middleware/adminChecker");
const { uid } = require("uid");

const router = express.Router();

router.get("/find/:id", async (req, res) => {
  try {
    const product = await Product.findOne({ productID: req.params.id });
    res.send(product.toObject());
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .send({ error: `Couldn't find a product with the ID: ${req.params.id}` });
  }
});

router.get("/all", async (req, res) => {
  try {
    const products = await Product.find({});
    res.send(products.map((product) => product.toObject()));
  } catch (error) {
    console.error(error);
    res.status(500).send("Error products");
  }
});

router.get("/related/:id", async (req, res) => {
  try {
    const product = await Product.findOne({ productID: req.params.id });

    if (!product)
      return res
        .status(400)
        .send({ error: `No product found with ID:  ${productID}` });

    const related_products = await Product.find({
      $and: [
        { productID: { $ne: product.productID } },
        { $or: [{ category: product.category }, { brand: product.brand }] },
      ],
    });

    if (related_products.length == 0)
      return res.status(400).send({ error: "No related products found" });
    res.send(related_products);
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: "Error finding related products" });
  }
});

router.get("/category/:id", async (req, res) => {
  try {
    const product = await Product.find({ category: req.params.id });
    res.send(product);
  } catch (error) {
    console.error(error);
    res.status(500).send({
      error: `Couldn't find products with category: ${req.params.id}`,
    });
  }
});

router.post("/add", adminAuth, async (req, res) => {
  try {
    const {
      name,
      description,
      category,
      brand,
      price,
      image,
      inStock,
      countInStock,
    } = req.body;

    let images;

    if (req.body.images && req.body.images !== []) {
      images = req.body.images;
    }

    const product = new Product({
      name: name,
      description: description,
      category: category,
      brand: brand,
      price: price,
      image: image,
      images: images,
      inStock: inStock,
      countInStock: countInStock,
      productID: uid(16),
    });

    await product.save();

    res.send(product.toObject());
  } catch (error) {
    res.status(500).send({ error: "Error saving product" });
    console.log(error);
  }
});

router.post("/edit/:id", adminAuth, async (req, res) => {
  try {
    const {
      name,
      description,
      category,
      brand,
      price,
      image,
      inStock,
      countInStock,
    } = req.body;
    let product = await Product.findOne({ productID: req.params.id });

    if (!product) {
      return res.status(404).send({ error: "product not found" });
    }

    product.name = name;
    product.description = description;
    product.category = category;
    product.brand = brand;
    product.price = price;
    product.image = image;
    product.images = req.body.images ? req.body.images : [];
    product.inStock = inStock;
    product.countInStock = countInStock;

    await product.save();

    res.send(product.toObject());
  } catch (error) {
    res.status(500).send({ error: "Error updating product" });
    console.log(error);
  }
});

router.post("/delete/:id", adminAuth, async (req, res) => {
  try {
    const product = await Product.findOne({ productID: req.params.id });

    if (!product) {
      return res.status(404).send("Product not found");
    }

    await product.remove();

    res.send({ message: `Product with ID ${req.params.id} has been deleted` });
  } catch (error) {
    console.error(error);
    res.status(500).send({ error: "Error deleting product" });
  }
});

module.exports = router;

const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
dotenv.config();

module.exports = async (req, res, next) => {
  if (
    req.headers.authorization &&
    req.headers.authorization.includes("Bearer ")
  ) {
    try {
      const token = req.headers.authorization.split("Bearer ")[1];
      const decoded = jwt.verify(token, process.env.secret_key);

      req.user = decoded;

      if (decoded.role == "delivery") {
        next();
      } else {
        res.status(400).send({ Error: "Action not allowed" });
      }
    } catch (err) {
      res.status(400).send({ Error: "Invalid/expired Token" });
    }
  }
};
